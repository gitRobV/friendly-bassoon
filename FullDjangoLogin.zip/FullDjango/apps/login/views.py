# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import User

# Create your views here.
def index(request):
    if 'user_status' not in request.session or request.session['user_status'] != 'Authenticated':
        return redirect('/login')
    else:
        user = User.objects.get(id=request.session['user_id'])

    return render(request, 'login/index.html', {'user': user})

def login(request):
    return render(request, 'login/login.html')

def logout(request):
    del request.session['user_id']
    del request.session['user_status']
    return redirect('/')

def authenticate(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        validated = User.objects.check_login(post_data)

        if len(validated.errors) > 0:
            messages.error(request, "Hol'up, Try that shit again.")
            for err in validated.error:
                messages.error(request, err)
            return redirect('/')
        else:
            request.session['user_id'] = validated.data['id']
            request.session['user_status'] = validated.data['status']
            messages.success(request, "Welcome Back!")
    return redirect('/')



def register(request):
    return render(request, 'login/register.html')

def process(request):
    if request.method == 'POST':
        validated = User.objects.check_register(request.POST)
        if len(validated.errors) == 0:
            try:
                check_user = User.objects.get(email=validated.data['email'])
            except:
                check_user = False
            if check_user:
                data = {
                'f_name' :request.POST['f_name'],
                'l_name': request.POST['l_name'],
                'email': request.POST['email']
                }
                request.session['data'] = data
                messages.error(request, 'The Email provided is already registered. Choose a different email or login.')
                return redirect('/register')
            else:
                new_user = User.objects.create(f_name=validated.data['f_name'], l_name=validated.data['l_name'], email=validated.data['email'], password=validated.data['password'])
                request.session['user_id'] = new_user.id
                request.session['user_status'] = 'Authenticated'
                messages.success(request, 'Thank You for registering! Your user_id is ' + str(new_user.id))
                if 'data' in request.session:
                    del request.session['data']
                return redirect('/')
        else:
            for err in validated.errors:
                messages.error(request, err)
            return redirect('/register')

    return redirect('/register')
