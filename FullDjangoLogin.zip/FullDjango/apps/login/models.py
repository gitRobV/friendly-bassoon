# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from .validation import Validation
import bcrypt

class UserManager(models.Manager):

    def check_login(self, post_data):
        # create object that will be returned
        input_reqs = [
            ('email', 'email', post_data['email']),
            ('pass_check', 'password', post_data['password'], post_data['password'], 8, 16)
        ]
        validated = Validation(input_reqs)
        # Try to get user object with email address
        try:
            user = User.objects.get(email=validated.data['email'])
        except:
            user = False
            validated.errors.append('User Does not exist')
            return validated
        if user:
            validated.data['id'] = user.id
            validated.data['hash'] = user.password.encode()
            if bcrypt.hashpw(post_data['password'].encode(), validated.data['hash']) == validated.data['hash']:
                validated.data['status'] = 'Authenticated'
            else:
                validated.data['status'] = 'Failed'
        return validated

    def check_register(self, post_data):
        input_reqs = [
            ('alpha', 'f_name', post_data['f_name']),
            ('alpha', 'l_name', post_data['l_name']),
            ('email', 'email', post_data['email']),
            ('pass_check', 'password', post_data['password'], post_data['confirm_password'], 8, 16)
        ]
        validated = Validation(input_reqs)
        return validated


################################################################################


# Create your models here.
class User(models.Model):
    f_name = models.CharField(max_length=30)
    l_name = models.CharField(max_length=40)
    email = models.CharField(max_length=65)
    password = models.CharField(max_length=255)
    salt = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()
